#!/bin/bash

# Настройки
OUTPUT_FILE="project_code.txt"  # Имя итогового файла
IGNORE_FILES=("go.mod" "go.sum" "*.log" "*.tmp")  # Файлы для игнорирования

# Очистка предыдущего файла
> "$OUTPUT_FILE"

# Рекурсивно ищем .go файлы и добавляем их в OUTPUT_FILE
find . -name "*.go" | while read file; do
    # Проверяем, не в списке ли игнора
    skip=0
    for ignore in "${IGNORE_FILES[@]}"; do
        if [[ "$file" == *"$ignore"* ]]; then
            skip=1
            break
        fi
    done

    if [ $skip -eq 0 ]; then
        echo "// File: $file" >> "$OUTPUT_FILE"
        cat "$file" >> "$OUTPUT_FILE"
        echo -e "\n\n" >> "$OUTPUT_FILE"
    fi
done

echo "✅ Код собран в $OUTPUT_FILE"